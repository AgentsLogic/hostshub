import { redirect } from "next/navigation"

export default function DirectDashboardPage() {
  redirect("/dashboard")
}

