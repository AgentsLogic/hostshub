declare global {
  interface Window {
    // Add any global window properties here
  }
}

// Add any global type definitions here

